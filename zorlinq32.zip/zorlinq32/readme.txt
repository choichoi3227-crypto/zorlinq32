=== Zorlinq32 ===
Contributors: choisungwon
Tags: performance, cache, security, seo, storage
Requires at least: 5.8
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.1.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

An all-in-one WordPress optimization plugin bundling 32 features across analytics, SEO, ad protection, caching, and security.

== Description ==

Zorlinq32 is an optimization plugin designed to improve the performance, search visibility, and stability of your WordPress site. The "32" in the name reflects the number of distinct features bundled into a single, cohesive plugin.

**Key Features**

* Change the admin login URL (block direct access to wp-login.php)
* File-based page caching to reduce server load
* Built-in analytics dashboard (organic / referral / direct traffic breakdown, daily-to-yearly trend charts, top posts, and search keywords where the search engine provides them) stored entirely in your own database — no external analytics service involved
* AdSense invalid-click protection: observes (never blocks) clicks on your ad slots, and hides ad slots for a configurable period from visitors (IP + device fingerprint) who exceed a configurable click threshold within a configurable time window, with country- and IP-level blocking as well
* Hosting storage usage monitoring with scheduled checks and email alerts when a threshold is exceeded
* Full SEO toolkit: unlimited focus keywords per post, an on-page SEO score with a detailed checklist, an approximate keyword competition indicator, category/author/site-wide SEO fields, Open Graph tags, and search engine ownership verification tags (Google, Naver, Bing)
* Auto-generated XML sitemap (separate feeds for posts, pages, and categories) and an automatically managed robots.txt that blocks core/admin paths
* Automatic search engine indexing requests (IndexNow protocol for Bing/Naver/Yandex, and sitemap ping for Google) whenever a post is published or updated
* Header / body / footer custom code insertion for analytics, verification tags, or other scripts
* Performance tuning: revision limits, heartbeat control, removal of emoji/embed scripts, lazy loading of images, and more
* Security hardening: XML-RPC blocking, login attempt limiting, security headers, username exposure prevention, and more
* Admin experience: dashboard/admin bar cleanup, custom login screen logo
* Content optimization: comment spam prevention (honeypot), disabling unnecessary image size generation, restricting search scope
* Cron stabilization: monitoring of delayed or missed scheduled tasks, automatic retry, safe self-ping, and guidance for connecting a real server-side cron
* AI writing assistant (Gemini API): generates full post drafts, SEO title/meta description/slug/focus keyword, and multi-schema markup (Article/FAQ/Product Review) directly from the post editor sidebar
* AI thumbnail generator: creates featured images in five distinct visual styles (Poster, Minimal, Photo-realistic, Typography, Branding) via a local headless browser, the cloud-press Cloudflare Worker (Workers AI FLUX.1 schnell, with an always-succeeding SVG card fallback), or Pollinations.ai (if an API key is registered) — plus support for custom background templates with editable title/subtitle text overlays

= About the SEO Score =

The SEO score is calculated entirely from on-page signals already present in your content (keyword placement in the title,
URL, meta description, intro, headings, image alt text, keyword density, content length, internal/external links, and more).
It does not rely on any paid third-party search-volume API. The same is true for the keyword competition indicator, which is
an approximate signal based on keyword specificity and how often the same keyword is already used elsewhere on your site —
not real search volume data. Both are meant as on-page optimization guidance, not a ranking guarantee.

= About AdSense Invalid-Click Protection =

This feature never intercepts, blocks, or manipulates ad clicks in any way — every click is always delivered to
AdSense normally. It only observes click events on your ad slots for statistical purposes, and if a visitor
exceeds the click threshold you configure within your configured time window, that visitor's ad slots are left
empty on subsequent page loads for a configurable duration. Deciding what content (including ad slots) to show
to which visitor is a publisher's normal prerogative and is separate from click manipulation.

= About Cron (Scheduled Task) Accuracy =

WordPress's default scheduled task system (WP-Cron) only runs when a visitor requests a page.
This is a structural characteristic of WordPress core, and no plugin can completely remove this limitation.

Zorlinq32 helps compensate for this limitation as much as possible by providing delay/miss monitoring,
automatic retry of its own tasks, and a safely scoped self-ping feature. For the most accurate execution,
the plugin also provides guidance for connecting a real server-side cron (Linux cron) through your hosting provider.

This plugin is designed with stability as the top priority. Every feature is disabled by default and only
runs once explicitly enabled by the user. All external API calls and file operations are wrapped in exception
handling so that an error never brings down the entire site.

**Requirements**

* PHP 7.4 or higher
* WordPress 5.8 or higher
* MySQL 5.6 or higher (or MariaDB 10.1 or higher)

= Privacy and External Services =

The built-in analytics feature stores visit records only in your own WordPress database. It never sends visitor
data to any third party. Visitor IP addresses are never stored in raw form — only a one-way hash (rotated daily)
used to avoid double-counting the same visitor on the same day. Logged-in users (including site administrators)
are excluded from analytics collection.

When the automatic indexing feature is enabled, the plugin sends the URL of newly published or updated posts to the
IndexNow API (api.indexnow.org) and/or Google's sitemap ping endpoint (google.com/ping). No personal visitor data is
sent — only the post URL itself. This feature is disabled by default and only runs after the user enables it.

* IndexNow protocol overview: https://www.indexnow.org/
* Google's sitemap ping documentation: https://developers.google.com/search/docs

== Installation ==

1. Upload the plugin zip file via WordPress Admin > Plugins > Add New > Upload Plugin.
2. Activate the plugin.
3. Go to the "Zorlinq32" admin menu and enable the features you need individually.

== Frequently Asked Questions ==

= I enabled a feature and now my site looks broken. What do I do? =

Uncheck "Enable this feature" on the relevant settings screen to revert immediately.
If you enabled the login URL change feature and are locked out, you can rename the plugin folder
via (S)FTP to force-deactivate the plugin.

= My storage usage is not showing up =

Some hosting environments disable PHP's disk_total_space function for security reasons.
In that case, the plugin safely displays "unavailable" instead of showing an error.

= Does the SEO score guarantee a search ranking? =

No. It is an on-page optimization checklist based on your content only, not a prediction of actual search rankings,
which depend on many factors outside any plugin's control.

= Can I use this alongside other caching/security/SEO plugins? =

We recommend not running the caching and login security features alongside other plugins that provide
similar functionality. The SEO features are automatically disabled if Yoast SEO, Rank Math, or All in One SEO
is detected, to prevent conflicts.

== Screenshots ==

1. Dashboard - view the status of all features at a glance
2. Storage monitoring screen
3. SEO score and keyword checklist on the post editor screen

== Changelog ==

= 1.1.5 =
* **Fixed a long-standing content-truncation bug** where AI-generated post bodies were frequently cut off mid-sentence or mid-tag ("정상 생성은 가끔씩만" — only occasionally complete). Root cause: the plugin never inspected Gemini's `finishReason` field, so responses truncated by the `maxOutputTokens` limit (`finishReason: "MAX_TOKENS"`) were silently treated as complete as long as they already exceeded the 1,200-character continuation threshold — meaning a post that happened to reach, say, 3,000 characters before being cut off would never trigger a continuation pass and would be saved truncated. Fixes:
  1. `extract_text()` now recognizes `MAX_TOKENS` (and `SAFETY`/`RECITATION`) finish reasons and reports them explicitly instead of returning a generic "no text" error.
  2. The continuation loop now triggers whenever *any* of the following is true: character count is below target, the API reported `MAX_TOKENS`, or the resulting HTML looks structurally unclosed (e.g. ends mid-`<li>` or mid-`<p>` instead of a properly closed block tag) — not just character count alone.
  3. Continuation prompts now distinguish between "add a new section" (original behavior) and "finish the sentence/tag that was cut off, then continue" (new), so a mid-sentence truncation is completed naturally instead of an unrelated new section being tacked on after a broken fragment.
  4. `maxOutputTokens` raised from 8,000 to 12,000 for the main generation call to reduce how often truncation happens in the first place, given how demanding the structural requirements (4+ H2 sections, 2-3 H3 per H2, etc.) already are.
  5. Added a final safety net (`close_dangling_html()`) that safely closes any still-unclosed tags if every continuation attempt is exhausted, so a worst-case result is never saved with visibly broken markup.
* **Reworked AI-thumbnail image generation to add a working cloud-press Worker path.** The [cloud-press](https://github.com/choichoi3227-crypto/cloud-press) repository's `/api/image` endpoint has been completely rewritten (see that repo's own changelog): its previous "procedural neural-field noise" bitmap generator (which produced abstract color-noise images with no text or layout) has been replaced with a real two-stage pipeline — (1) Cloudflare Workers AI (`flux-1-schnell`) attempted once per request when bound, falling back to (2) a self-contained SVG "headless card" renderer that reproduces this plugin's own headless-browser card layout (gradient background, blurred glass panels, badge, title/subtitle typography) and always succeeds without any external dependency.
  1. Image generation now routes: **① local headless browser (unchanged, first priority) → ② if no Pollinations API key is registered, the cloud-press Worker's `/api/image` is used 100% of the time → ③ if a Pollinations API key *is* registered, Pollinations is tried first (as before) and the cloud-press Worker is now used as the final fallback if the entire Pollinations model chain fails.**
  2. This Worker is the exact same deployment already used for search grounding (`/api/search`) and topic research (`/api/research`) — no separate deployment or additional URL field is needed, only more endpoints on the same base URL.
  3. Settings-page copy (both the "Search·Research·Image Worker URL" field and the "Pollinations API Key" field) updated to explain the new routing order.
  4. The existing SVG-detection logic in the thumbnail-save pipeline (`mime === 'image/svg+xml'` → skip canvas text compositing, save as-is) already handled this case correctly with no changes needed, since it was originally built for the local headless-browser's potential SVG output.

= 1.1.4 =
* Search-grounding backend switched from a Groq-based Cloudflare Worker to the new [cloud-press](https://github.com/choichoi3227-crypto/cloud-press) GitHub repository (Cloudflare Workers / Pages Functions). This affects both the content-generation search grounding (`GET /api/search`) and the AI-thumbnail topic research (`POST /api/research`) — both are now served by the same cloud-press deployment.
* The "Search-grounding Worker URL" field now expects a cloud-press *base* URL (e.g. `https://cloudpress-search-endpoint.your-subdomain.workers.dev`). You no longer need to append `/api/search` or `/api/research` yourself — the plugin appends the correct path automatically, and will also strip a mistakenly-included `/api/search` or `/api/research` suffix if you paste one in.
* cloud-press's `/api/research` endpoint returns the same `research` JSON shape the plugin already expected (`actual_meaning`, `visual_context`, `hero_shot`, `color_mood`, `key_visuals`, `category`, `wrong_interpretation`, `emotional_tone`, `text_color_hex`, `accent_color_hex`), generated by rule-based color/category matching over the live search results — no Cloudflare AI binding is required for this to work.
* If you self-host cloud-press and optionally enable its Workers AI binding for extra research polish, no plugin changes are needed — the response shape is identical either way.
* Settings-page copy and inline documentation updated throughout to reference cloud-press instead of the retired Groq-based worker.

= 1.1.3 =
* Fixed a serious topic-mismatch bug where certain topics (e.g. "카카오톡 PC버전 다운로드" / "KakaoTalk PC version download") produced completely unrelated thumbnails, including images of people/fashion models — a direct violation of the plugin's own "no people" rule for non-photo-realistic styles. Root causes and fixes:
  1. Gemini's final prompt-writing call (Phase B) was trusted blindly — if it ignored its own "no people" instruction (which text-only LLM instructions cannot fully guarantee), nothing caught it before the prompt reached the image model. A post-generation safety check now scans the returned prompt for person/face/model-related wording (for every style except Photo-realistic) and discards it in favor of the locally built, research-grounded prompt if any is found.
  2. The local keyword-to-visual-concept fallback table (used whenever research/prompt-generation via Gemini fails) had no entry at all for messenger/chat apps (KakaoTalk, Line, WhatsApp, Telegram, Discord, etc.) or "PC version" wording, so those topics fell through to a generic catch-all and produced unpredictable results. Added dedicated, brand-safe entries (a speech-bubble-shaped graphic motif for messenger apps; a laptop/monitor with a download-arrow accent for "PC version" topics) that never reference real logos or UI.
* These two fixes work together: even when the Gemini research/prompt calls succeed, the output is now checked before use; when they fail, the safety-net fallback is now topic-aware for this common category instead of falling back to a generic description.

= 1.1.2 =
* Critical fix to the AI thumbnail research pipeline: the "Phase A" research prompt (which is supposed to take the search-grounding worker's results and have Gemini interpret them — actual meaning, hero visual, color mood, key visuals, emotional tone, text/accent colors) was built but never actually sent to the Gemini API. The final image prompt was therefore always generated from a bare, unresearched topic string, silently ignoring anything the search-grounding worker had found. This call is now made for real, with the worker's search results still gathered exactly as before (search itself has always been performed by the configured search-grounding Worker, not by Gemini) and passed to Gemini purely as reference material to interpret — Gemini never performs its own web search. On failure (no API key, rate limit, timeout) the plugin falls back to the previous local keyword-based estimate exactly as it did before.
* Search-grounding worker results are now requested in greater depth (5 → 8 results) and any per-result snippet/summary text the worker provides is now included, not just titles/URLs, giving the research step more concrete detail to work with.
* Search-grounding worker call timeout is now dynamically capped against the remaining request budget, so a slow worker response can no longer starve the following Gemini research/prompt-generation/image-generation steps of time within the 55-second request deadline.
* The "category" field returned by topic research (used for the CTA badge label in Branding-style thumbnails) is now actually populated — previously always empty due to the same dead research call.

= 1.1.1 =
* Critical fix: the final code-level fallback used when both the research/grounding worker and the Gemini prompt-writing call fail (`topic_to_visual_concept()`) contained a "please avoid a plain computer monitor with a chat bubble and a download arrow on a purple-blue gradient" instruction. Because FLUX cannot reliably parse negative phrasing, it read this as a literal description and generated exactly that scene regardless of topic (e.g. a UK train ticket/railcard promotion thumbnail rendering an iMac with chat/download icons). This fallback now describes only what to draw, in positive language derived from the actual topic — the words "computer/monitor/chat/download" no longer appear in its output under any circumstance. Also expanded the topic-to-visual keyword map to cover travel/ticket/discount topics (trains, flights, accommodation) so fewer topics fall through to the generic fallback at all.

= 1.1.0 =
* AI thumbnail generation overhaul: fixed the root cause of thumbnails always showing a computer/monitor in the background — a forced "no screen/monitor" negative phrase that FLUX misread as an instruction to draw one. Screen/device wording is now only used when the topic is actually about a device, app, or website.
* Style differentiation greatly increased: each of the 5 styles (Poster/Minimal/Photo-realistic/Typography/Branding) now combines layout × background × lighting pools (instead of just layout × background), and the prompt-generation instructions now include an explicit per-style vocabulary contrast table so styles can no longer converge on similar wording or composition.
* Image detail/quality improved: default FLUX.1 schnell steps raised from 4 to 8 (the model's maximum), reducing the "flat/plain" look reported by users.
* Every image generation call now uses a fresh cryptographically random seed (both in the Cloudflare Worker and the plugin), guaranteeing that repeated generations — even with the same topic and style — no longer look nearly identical.
* Image generation reliability hardened: automatic retry with a new seed on Worker failure/timeout/empty image, and the Gemini research phase (which grounds every image in real topic research) now retries and always falls back to a deterministic topic analysis instead of silently generating from a bare, ungrounded topic string.
* Dashboard: "AI 글쓰기" and "AI 썸네일 템플릿" now appear as module rows with on/off status on the main dashboard (previously only reachable via the submenu).

= 1.0.0 =
* Initial public release as Zorlinq32 (32 reflects the number of distinct bundled features): analytics, SEO, AdSense protection, caching, storage monitoring, cron stabilization, security, and more.
* Unified SEO panel in the block editor sidebar (score + settings tabs), automatic schema markup (JSON-LD), automatic meta description, entity-style focus keyword input, human-readable sitemap view.
* Analytics: unique-visitor vs pageview distinction, cookie-based admin-traffic exclusion, configurable cache interval (1/5/10/30/60 min), one-click statistics reset, WordPress dashboard widget, real-time chart tooltips.
* AdSense protection: click-fraud detection with country/IP-based ad suppression only (never blocks site access); Cloudflare and AWS(CloudFront) signals improve detection accuracy with no API keys required.
* Server resource optimizations: scoped cache invalidation, batched cleanup queries, reduced redundant database queries.
* Quick Button block with enforced center alignment; reusable-block ("Op Template") pattern categorization fixed.
* AI writing assistant integrated: Gemini-powered content/SEO/schema generation from the post editor, plus a 5-style AI thumbnail generator (Poster/Minimal/Photo-realistic/Typography/Branding) backed by Cloudflare Workers AI, with a dedicated API key registration UI and custom thumbnail template manager.

== Upgrade Notice ==

= 1.0.0 =
Initial public release.
