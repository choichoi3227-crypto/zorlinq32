<?php
/**
 * 구글 계정 연동 이미지 생성(Vertex AI Imagen) 모듈.
 *
 * 용어 정리: 사용자가 "Google Flow"라고 부른 기능은 실제로는 프로그래밍 방식
 * 호출이 불가능한 구글의 영상 제작 웹앱(공개 API 없음)입니다. 이 모듈이 실제로
 * 연동하는 것은 구글 클라우드의 Vertex AI Imagen(이미지 생성 모델) API이며,
 * "관리자 구글 계정으로 로그인해 승인하면 그 이후 이미지 생성이 그 계정 권한으로
 * 백그라운드에서 자동 수행된다"는 사용자 경험은 동일하게 구현됩니다.
 *
 * 인증 방식: OAuth 2.0 Authorization Code 플로우(구글 표준).
 * - 관리자가 구글 클라우드 콘솔에서 발급받은 OAuth 클라이언트 ID/Secret과
 *   GCP 프로젝트 ID를 설정 화면에 입력합니다(사용자가 직접 발급 — 이 플러그인은
 *   대신 클라우드 프로젝트를 만들어주지 않습니다).
 * - "구글 계정으로 연결" 버튼을 누르면 구글 동의 화면으로 이동하고, 승인하면
 *   인증 코드가 담긴 콜백이 이 사이트로 돌아옵니다.
 * - 인증 코드를 리프레시 토큰으로 교환해 암호화 저장합니다. 접근 토큰(수명 짧음,
 *   보통 1시간)은 만료될 때마다 리프레시 토큰으로 자동 재발급받아 갱신하므로,
 *   사용자가 직접 "연결 해제"를 누르기 전까지는 재로그인이 필요 없습니다.
 * - 저장되는 리프레시 토큰은 이 사이트의 고유 키(AUTH_KEY/AUTH_SALT 기반)로
 *   암호화되어 옵션 테이블에 저장됩니다. 평문으로는 저장하지 않습니다.
 *
 * 이미지 생성 우선순위에서 이 모듈은 최우선 단계입니다:
 * 구글 Imagen(이 모듈) → 헤드리스 브라우저 카드 → Pollinations → cloud-press Worker(최후).
 * 연결되어 있지 않거나 호출이 실패하면 즉시 다음 단계로 자동 폴백하며, 이 모듈의
 * 오류가 전체 이미지 생성 기능을 막지 않습니다.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Zorlinq32_Google_Imagen {

	private static $instance = null;

	const OPTION_CONFIG       = 'zorlinq32_google_imagen_config';       // client_id, client_secret, project_id
	const OPTION_TOKEN        = 'zorlinq32_google_imagen_token';        // 암호화된 refresh_token + 계정 이메일 등 연결 상태
	const OPTION_ACCESS_CACHE = 'zorlinq32_google_imagen_access_cache'; // 단기 access_token 캐시

	const OAUTH_AUTH_ENDPOINT   = 'https://accounts.google.com/o/oauth2/v2/auth';
	const OAUTH_TOKEN_ENDPOINT  = 'https://oauth2.googleapis.com/token';
	const OAUTH_REVOKE_ENDPOINT = 'https://oauth2.googleapis.com/revoke';
	// [스코프 관련 중요 사실] 구글은 Vertex AI 모델 호출(predict/generateContent)에
	// 대해 cloud-platform보다 더 좁은 전용 스코프를 제공하지 않습니다. 즉
	// "이미지 생성 API만 정확히 허용하고 나머지는 다 막는" 스코프는 구글 쪽에
	// 존재하지 않으며, 더 좁은 스코프(read-only 등)를 쓰면 생성 호출 자체가
	// 권한 오류로 실패합니다. 대신 다음 두 가지로 실질적 위험을 최소화합니다:
	// 1) 요청하신 대로 이 Client ID/Secret은 오직 이 OAuth 흐름(이미지 생성
	//    연동) 목적으로만 코드 전체에서 사용되며, 다른 기능이 이 자격증명이나
	//    발급된 토큰을 재사용하지 않습니다(아래 generate_image()가 유일한 소비처).
	// 2) 실제로 어떤 GCP 리소스에 접근 가능한지는 궁극적으로 "그 프로젝트에서
	//    이 서비스 계정/사용자에게 부여된 IAM 역할"이 결정합니다. 구글 클라우드
	//    콘솔의 IAM 설정에서 이 계정에 "Vertex AI 사용자(Vertex AI User)"
	//    역할만 부여해두면, 이 앱이 실제로 호출할 수 있는 범위는 자연스럽게
	//    Vertex AI로 좁혀집니다 — 이 방식이 구글 생태계에서 실제로 이 요구를
	//    달성하는 표준적인 방법입니다.
	const OAUTH_SCOPE = 'https://www.googleapis.com/auth/cloud-platform';

	// [모델] "Nano Banana"는 구글 Gemini 이미지 생성 모델(Gemini 2.5 Flash Image)의
	// 커뮤니티 별칭입니다. 정식 모델 ID는 구글이 수시로 조정할 수 있어, 기본값을
	// 두되 관리자 설정 화면에서 직접 override할 수 있게 합니다(향후 "Nano Banana 2"
	// 등 새 버전이 나오면 코드 수정 없이 설정값만 바꾸면 됩니다).
	const DEFAULT_MODEL_ID = 'gemini-2.5-flash-image';

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// admin-post 훅은 로그인한 관리자만 도달 가능한 표준 워드프레스 진입점이라
		// is_admin() 조건 없이도 안전합니다(핸들러 내부에서 권한을 다시 확인합니다).
		add_action( 'admin_post_zorlinq32_google_imagen_connect', array( $this, 'handle_connect_redirect' ) );
		add_action( 'admin_post_zorlinq32_google_imagen_callback', array( $this, 'handle_oauth_callback' ) );
		add_action( 'wp_ajax_zorlinq32_google_imagen_save_config', array( $this, 'ajax_save_config' ) );
		add_action( 'wp_ajax_zorlinq32_google_imagen_disconnect', array( $this, 'ajax_disconnect' ) );
	}

	/* ════════════════════════════════════════════════════════
	   설정 저장 (Client ID / Secret / GCP 프로젝트 ID)
	════════════════════════════════════════════════════════ */

	public function ajax_save_config() {
		check_ajax_referer( 'zorlinq32_ai_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => '권한 없음' ) );
		}

		$client_id     = isset( $_POST['client_id'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['client_id'] ) ) ) : '';
		$client_secret = isset( $_POST['client_secret'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['client_secret'] ) ) ) : '';
		$project_id    = isset( $_POST['project_id'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['project_id'] ) ) ) : '';
		$model_id      = isset( $_POST['model_id'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['model_id'] ) ) ) : '';

		if ( '' === $client_id || '' === $project_id ) {
			wp_send_json_error( array( 'message' => 'Client ID와 GCP 프로젝트 ID는 필수입니다.' ) );
		}

		$existing = self::get_config();

		// Secret 입력란을 비워두고 저장하면(이미 등록된 값을 그대로 유지하고 싶은 경우)
		// 기존 값을 보존합니다. 완전히 새 값이 들어온 경우에만 덮어씁니다.
		if ( '' === $client_secret && ! empty( $existing['client_secret'] ) ) {
			$client_secret = $existing['client_secret'];
		}

		if ( '' === $model_id ) {
			$model_id = self::DEFAULT_MODEL_ID;
		}

		update_option(
			self::OPTION_CONFIG,
			array(
				'client_id'     => $client_id,
				'client_secret' => $client_secret,
				'project_id'    => $project_id,
				'model_id'      => $model_id,
			),
			false
		);

		wp_send_json_success( array( 'message' => '구글 연동 설정이 저장되었습니다. 이제 "구글 계정으로 연결"을 눌러주세요.' ) );
	}

	public static function get_config() {
		$defaults = array( 'client_id' => '', 'client_secret' => '', 'project_id' => '', 'model_id' => self::DEFAULT_MODEL_ID );
		$saved    = get_option( self::OPTION_CONFIG, array() );
		$config   = wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
		if ( '' === $config['model_id'] ) {
			$config['model_id'] = self::DEFAULT_MODEL_ID;
		}
		return $config;
	}

	/**
	 * 리디렉션 URI는 구글 클라우드 콘솔의 OAuth 클라이언트 설정에 "승인된
	 * 리디렉션 URI"로 정확히 등록되어 있어야 합니다. admin-post.php 경로를
	 * 사용해 워드프레스 라우팅(퍼머링크 설정과 무관하게 항상 동작)에 안전하게 걸칩니다.
	 */
	public static function get_redirect_uri() {
		return admin_url( 'admin-post.php?action=zorlinq32_google_imagen_callback' );
	}

	/* ════════════════════════════════════════════════════════
	   OAuth 연결 시작 (동의 화면으로 리디렉션)
	════════════════════════════════════════════════════════ */

	public function handle_connect_redirect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '권한이 없습니다.', 'zorlinq32' ) );
		}
		check_admin_referer( 'zorlinq32_google_imagen_connect' );

		$config = self::get_config();
		if ( '' === $config['client_id'] || '' === $config['client_secret'] ) {
			wp_safe_redirect(
				add_query_arg(
					array( 'zorlinq32_gimg_error' => rawurlencode( 'Client ID/Secret을 먼저 저장해주세요.' ) ),
					admin_url( 'admin.php?page=zorlinq32-ai-writer' )
				)
			);
			exit;
		}

		// CSRF 방지용 state 값을 짧게 저장해두고, 콜백에서 그대로 되돌아오는지 검증합니다.
		$state = wp_generate_password( 24, false );
		set_transient( 'zorlinq32_gimg_oauth_state_' . get_current_user_id(), $state, 10 * MINUTE_IN_SECONDS );

		$params = array(
			'client_id'              => $config['client_id'],
			'redirect_uri'           => self::get_redirect_uri(),
			'response_type'          => 'code',
			'scope'                  => self::OAUTH_SCOPE,
			'access_type'            => 'offline', // refresh_token을 받기 위해 필수.
			'prompt'                 => 'consent',  // 매번 동의 화면을 보여줘 refresh_token 재발급을 보장(구글은 최초 1회만 기본 발급).
			'state'                  => $state,
			'include_granted_scopes' => 'true',
		);

		// [버그 수정] wp_safe_redirect()는 워드프레스가 "안전하다"고 인식하지 않는
		// 외부 호스트(accounts.google.com 등)로의 리다이렉트를 차단하고, 대신
		// 조용히 관리자 홈(/wp-admin/)으로 되돌려 버립니다. 이 때문에 "구글 계정으로
		// 연결" 버튼을 눌러도 구글 로그인 화면 대신 그냥 /wp-admin/index.php로
		// 이동해버리는 문제가 있었습니다. 구글 동의 화면은 이 플러그인이 제어할 수
		// 없는 외부 사이트이므로, 여기서는 의도적으로 wp_redirect()를 사용합니다.
		// (URL 자체는 이 함수 내부에서 구성한 값이라 사용자 입력이 그대로 반영되지
		// 않으므로 오픈 리다이렉트 위험은 없습니다.)
		wp_redirect( self::OAUTH_AUTH_ENDPOINT . '?' . http_build_query( $params ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- 의도적: 외부(구글) OAuth 동의 화면으로 이동해야 하며 URL은 이 함수 내부에서만 구성됨.
		exit;
	}

	/* ════════════════════════════════════════════════════════
	   OAuth 콜백 처리 (인증 코드 → 토큰 교환 → 암호화 저장)
	════════════════════════════════════════════════════════ */

	public function handle_oauth_callback() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '권한이 없습니다.', 'zorlinq32' ) );
		}

		$redirect_back = admin_url( 'admin.php?page=zorlinq32-ai-writer' );

		try {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 구글이 리디렉션시키는 콜백이라 워드프레스 nonce를 실을 수 없음. 대신 자체 발급 state 값으로 CSRF를 검증합니다.
			if ( isset( $_GET['error'] ) ) {
				throw new \Exception( '구글이 인증을 거부했습니다: ' . sanitize_text_field( wp_unslash( $_GET['error'] ) ) );
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$state       = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
			$saved_state = get_transient( 'zorlinq32_gimg_oauth_state_' . get_current_user_id() );
			delete_transient( 'zorlinq32_gimg_oauth_state_' . get_current_user_id() );

			if ( empty( $state ) || empty( $saved_state ) || ! hash_equals( (string) $saved_state, $state ) ) {
				throw new \Exception( '인증 요청이 만료되었거나 위조되었습니다. 다시 시도해주세요.' );
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$code = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
			if ( empty( $code ) ) {
				throw new \Exception( '인증 코드가 없습니다.' );
			}

			$config   = self::get_config();
			$response = wp_remote_post(
				self::OAUTH_TOKEN_ENDPOINT,
				array(
					'timeout' => 20,
					'body'    => array(
						'code'          => $code,
						'client_id'     => $config['client_id'],
						'client_secret' => $config['client_secret'],
						'redirect_uri'  => self::get_redirect_uri(),
						'grant_type'    => 'authorization_code',
					),
				)
			);

			if ( is_wp_error( $response ) ) {
				throw new \Exception( '토큰 교환 요청 실패: ' . $response->get_error_message() );
			}

			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( empty( $body['refresh_token'] ) ) {
				// 이미 한 번 연결된 적이 있는 클라이언트는 구글이 refresh_token을 다시
				// 내려주지 않을 수 있습니다(prompt=consent를 강제했으므로 흔치 않지만,
				// 안전하게 안내합니다).
				throw new \Exception(
					empty( $body['access_token'] )
						? '토큰 발급에 실패했습니다: ' . wp_json_encode( $body )
						: 'refresh_token을 받지 못했습니다. 구글 계정 설정(myaccount.google.com/permissions)에서 이 앱의 접근 권한을 제거한 뒤 다시 연결해주세요.'
				);
			}

			// 연결된 구글 계정 이메일을 함께 저장해 관리자 화면에 "어떤 계정으로
			// 연결되어 있는지" 표시할 수 있게 합니다(userinfo 조회는 실패해도 연결 자체는 유효).
			$email = '';
			if ( ! empty( $body['access_token'] ) ) {
				$userinfo_resp = wp_remote_get(
					'https://www.googleapis.com/oauth2/v3/userinfo',
					array(
						'timeout' => 10,
						'headers' => array( 'Authorization' => 'Bearer ' . $body['access_token'] ),
					)
				);
				if ( ! is_wp_error( $userinfo_resp ) ) {
					$userinfo = json_decode( wp_remote_retrieve_body( $userinfo_resp ), true );
					$email    = isset( $userinfo['email'] ) ? sanitize_email( $userinfo['email'] ) : '';
				}
			}

			self::store_refresh_token( $body['refresh_token'], $email );

			wp_safe_redirect( add_query_arg( 'zorlinq32_gimg_connected', '1', $redirect_back ) );
			exit;
		} catch ( \Throwable $e ) {
			Zorlinq32_Logger::log( '구글 Imagen OAuth 콜백 오류: ' . $e->getMessage() );
			wp_safe_redirect( add_query_arg( 'zorlinq32_gimg_error', rawurlencode( $e->getMessage() ), $redirect_back ) );
			exit;
		}
	}

	/* ════════════════════════════════════════════════════════
	   토큰 저장/암호화 유틸
	════════════════════════════════════════════════════════ */

	/**
	 * 이 사이트 고유의 암호화 키를 워드프레스 인증 솔트에서 파생시킵니다.
	 * wp-config.php를 벗어나 다른 서버로 옵션 테이블만 복사해가도 해독할 수
	 * 없도록(같은 AUTH_KEY/AUTH_SALT를 모르면 무의미한 값), DB 유출 시
	 * 최소한의 방어선이 되도록 합니다. 완전한 비밀 관리 시스템은 아니지만
	 * 평문 저장보다는 훨씬 안전합니다.
	 */
	private static function get_encryption_key() {
		$material = ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' ) . ( defined( 'AUTH_SALT' ) ? AUTH_SALT : '' );
		if ( '' === $material ) {
			// 극히 드물게 솔트가 정의되지 않은 환경(로컬 개발 등)을 위한 안전한 폴백.
			// 이 경우에도 사이트별 고유값(옵션 테이블에 자동 생성해 보관)을 사용해
			// 최소한의 사이트 간 격리를 유지합니다.
			$fallback = get_option( 'zorlinq32_google_imagen_fallback_key' );
			if ( empty( $fallback ) ) {
				$fallback = wp_generate_password( 64, true, true );
				update_option( 'zorlinq32_google_imagen_fallback_key', $fallback, false );
			}
			$material = $fallback;
		}
		return hash( 'sha256', $material, true );
	}

	private static function encrypt_token( $plain ) {
		$key    = self::get_encryption_key();
		$iv     = openssl_random_pseudo_bytes( 16 );
		$cipher = openssl_encrypt( $plain, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv );
		if ( false === $cipher ) {
			return '';
		}
		return base64_encode( $iv . $cipher ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- 저장용 인코딩이며 난독화 목적이 아닙니다.
	}

	private static function decrypt_token( $encoded ) {
		$raw = base64_decode( $encoded, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		if ( false === $raw || strlen( $raw ) < 17 ) {
			return '';
		}
		$iv     = substr( $raw, 0, 16 );
		$cipher = substr( $raw, 16 );
		$key    = self::get_encryption_key();
		$plain  = openssl_decrypt( $cipher, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv );
		return false === $plain ? '' : $plain;
	}

	private static function store_refresh_token( $refresh_token, $email = '' ) {
		update_option(
			self::OPTION_TOKEN,
			array(
				'refresh_token_enc' => self::encrypt_token( $refresh_token ),
				'email'              => $email,
				'connected_at'       => current_time( 'mysql' ),
			),
			false
		);
		// 계정이 바뀌었을 수 있으니 이전 access_token 캐시는 무효화합니다.
		delete_option( self::OPTION_ACCESS_CACHE );
	}

	/**
	 * 현재 연결 상태를 반환합니다. 관리자 화면에서 "연결됨/안 됨" 표시에 사용합니다.
	 *
	 * @return array{connected: bool, email: string, connected_at: string}
	 */
	public static function get_connection_status() {
		$token     = get_option( self::OPTION_TOKEN, array() );
		$connected = is_array( $token ) && ! empty( $token['refresh_token_enc'] );
		return array(
			'connected'    => $connected,
			'email'        => $connected && ! empty( $token['email'] ) ? $token['email'] : '',
			'connected_at' => $connected && ! empty( $token['connected_at'] ) ? $token['connected_at'] : '',
		);
	}

	/**
	 * 사용자가 "연결 해제"를 누르면 구글 쪽 토큰도 무효화(revoke)하고, 로컬에
	 * 저장된 암호화 토큰도 완전히 삭제합니다. 이후에는 다시 로그인해야 합니다.
	 */
	public function ajax_disconnect() {
		check_ajax_referer( 'zorlinq32_ai_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => '권한 없음' ) );
		}

		$token = get_option( self::OPTION_TOKEN, array() );
		if ( is_array( $token ) && ! empty( $token['refresh_token_enc'] ) ) {
			$refresh_token = self::decrypt_token( $token['refresh_token_enc'] );
			if ( '' !== $refresh_token ) {
				// 구글 서버 측에서도 이 앱의 접근 권한을 명시적으로 취소합니다.
				// 실패해도(네트워크 오류 등) 로컬 연결은 어차피 끊으므로 결과를 기다리지 않습니다.
				wp_remote_post(
					self::OAUTH_REVOKE_ENDPOINT,
					array(
						'timeout' => 8,
						'body'    => array( 'token' => $refresh_token ),
					)
				);
			}
		}

		delete_option( self::OPTION_TOKEN );
		delete_option( self::OPTION_ACCESS_CACHE );

		wp_send_json_success( array( 'message' => '구글 계정 연결이 해제되었습니다.' ) );
	}

	/* ════════════════════════════════════════════════════════
	   access_token 자동 갱신
	════════════════════════════════════════════════════════ */

	/**
	 * 유효한 access_token을 반환합니다. 캐시된 토큰이 아직 유효하면 그대로
	 * 재사용하고, 만료되었으면 refresh_token으로 자동 재발급받아 캐시를
	 * 갱신합니다. 연결이 안 되어 있으면 빈 문자열을 반환합니다(예외를 던지지
	 * 않음 — 호출부가 다음 폴백 단계로 자연스럽게 넘어갈 수 있도록).
	 *
	 * @return string
	 */
	private static function get_valid_access_token() {
		$cache = get_option( self::OPTION_ACCESS_CACHE, array() );
		if ( is_array( $cache ) && ! empty( $cache['access_token'] ) && ! empty( $cache['expires_at'] ) ) {
			// 만료 60초 전에는 미리 갱신해 요청 도중 만료되는 경합을 피합니다.
			if ( time() < ( (int) $cache['expires_at'] - 60 ) ) {
				return $cache['access_token'];
			}
		}

		$token = get_option( self::OPTION_TOKEN, array() );
		if ( ! is_array( $token ) || empty( $token['refresh_token_enc'] ) ) {
			return '';
		}
		$refresh_token = self::decrypt_token( $token['refresh_token_enc'] );
		if ( '' === $refresh_token ) {
			return '';
		}

		$config = self::get_config();
		if ( '' === $config['client_id'] || '' === $config['client_secret'] ) {
			return '';
		}

		$response = wp_remote_post(
			self::OAUTH_TOKEN_ENDPOINT,
			array(
				'timeout' => 15,
				'body'    => array(
					'client_id'     => $config['client_id'],
					'client_secret' => $config['client_secret'],
					'refresh_token' => $refresh_token,
					'grant_type'    => 'refresh_token',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			Zorlinq32_Logger::log( '구글 Imagen access_token 갱신 실패: ' . $response->get_error_message() );
			return '';
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( empty( $body['access_token'] ) ) {
			// invalid_grant는 대개 "사용자가 구글 계정 설정에서 직접 권한을 취소함"을
			// 뜻합니다. 로컬에도 연결이 끊어졌음을 반영해 매 요청마다 헛되이 재시도하지 않게 합니다.
			if ( isset( $body['error'] ) && 'invalid_grant' === $body['error'] ) {
				delete_option( self::OPTION_TOKEN );
				delete_option( self::OPTION_ACCESS_CACHE );
				Zorlinq32_Logger::log( '구글 Imagen 연결이 만료/취소되어 로컬 연결 정보를 정리했습니다.' );
			} else {
				Zorlinq32_Logger::log( '구글 Imagen access_token 갱신 응답 이상: ' . wp_json_encode( $body ) );
			}
			return '';
		}

		$expires_in = isset( $body['expires_in'] ) ? (int) $body['expires_in'] : 3600;
		update_option(
			self::OPTION_ACCESS_CACHE,
			array(
				'access_token' => $body['access_token'],
				'expires_at'   => time() + $expires_in,
			),
			false
		);

		return $body['access_token'];
	}

	/* ════════════════════════════════════════════════════════
	   구글 이미지 생성 모델(Nano Banana / Gemini Flash Image) 호출
	════════════════════════════════════════════════════════ */

	/**
	 * 프롬프트로 이미지를 생성합니다. 연결이 안 되어 있거나 어떤 이유로든
	 * 실패하면 WP_Error를 반환해 호출부(ai-writer.php)가 다음 폴백 단계
	 * (헤드리스 브라우저 → Pollinations → Worker)로 자연스럽게 넘어가게 합니다.
	 *
	 * Nano Banana(Gemini Flash Image 계열)는 Imagen과 달리 Gemini의
	 * generateContent 엔드포인트로 호출하며, 이미지가 응답의
	 * candidates[].content.parts[].inlineData에 담겨 돌아옵니다.
	 *
	 * @param string $prompt  이미지 생성 프롬프트(영문 권장).
	 * @param int    $timeout 초 단위 타임아웃.
	 * @return array{body:string, mime:string}|WP_Error
	 */
	public static function generate_image( $prompt, $timeout = 30 ) {
		$status = self::get_connection_status();
		if ( ! $status['connected'] ) {
			return new WP_Error( 'gimg_not_connected', '구글 계정이 연결되어 있지 않습니다.' );
		}

		$access_token = self::get_valid_access_token();
		if ( '' === $access_token ) {
			return new WP_Error( 'gimg_no_token', '구글 액세스 토큰을 발급받지 못했습니다.' );
		}

		$config = self::get_config();
		if ( '' === $config['project_id'] ) {
			return new WP_Error( 'gimg_no_project', 'GCP 프로젝트 ID가 설정되어 있지 않습니다.' );
		}

		$model_id = '' !== $config['model_id'] ? $config['model_id'] : self::DEFAULT_MODEL_ID;

		// Vertex AI의 리전은 대부분의 계정에서 기본 제공되는 us-central1을 사용합니다.
		$endpoint = sprintf(
			'https://us-central1-aiplatform.googleapis.com/v1/projects/%s/locations/us-central1/publishers/google/models/%s:generateContent',
			rawurlencode( $config['project_id'] ),
			rawurlencode( $model_id )
		);

		$payload = array(
			'contents'         => array(
				array(
					'role'  => 'user',
					'parts' => array(
						array( 'text' => $prompt ),
					),
				),
			),
			'generationConfig' => array(
				// 이 모델 계열은 텍스트/이미지를 함께 반환할 수 있어, 이미지 모달리티를
				// 명시적으로 요청해 항상 이미지가 포함되도록 합니다.
				'responseModalities' => array( 'IMAGE' ),
			),
		);

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout' => $timeout,
				'headers' => array(
					'Authorization' => 'Bearer ' . $access_token,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code < 200 || $code >= 300 ) {
			$message = isset( $body['error']['message'] ) ? $body['error']['message'] : ( 'HTTP ' . $code );
			return new WP_Error( 'gimg_api_error', '구글 이미지 생성 오류(' . $model_id . '): ' . $message );
		}

		// candidates[0].content.parts[] 안에서 inlineData를 가진 첫 파트를 찾습니다
		// (텍스트 파트가 함께 섞여 올 수 있어 순회하며 이미지 파트만 고릅니다).
		$parts = $body['candidates'][0]['content']['parts'] ?? array();
		$b64   = '';
		$mime  = 'image/png';
		foreach ( (array) $parts as $part ) {
			if ( ! empty( $part['inlineData']['data'] ) ) {
				$b64  = $part['inlineData']['data'];
				$mime = ! empty( $part['inlineData']['mimeType'] ) ? $part['inlineData']['mimeType'] : 'image/png';
				break;
			}
		}

		if ( '' === $b64 ) {
			return new WP_Error( 'gimg_empty_response', '구글 이미지 생성 모델이 이미지를 반환하지 않았습니다.' );
		}

		$img_body = base64_decode( $b64, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		if ( false === $img_body || '' === $img_body ) {
			return new WP_Error( 'gimg_decode_failed', '구글 이미지 생성 응답을 디코딩하지 못했습니다.' );
		}

		return array( 'body' => $img_body, 'mime' => $mime );
	}
}
